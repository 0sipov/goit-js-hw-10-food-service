export default {
  menu: document.querySelector(".js-menu"),
};
