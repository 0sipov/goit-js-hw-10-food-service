import refs from "./refs.js";
const { menu: menuRef } = refs;

import menuItems from "../data/menu.json";

import menuTemplate from "../templates/menu.hbs";
let menuMarkup = menuTemplate(menuItems);

menuRef.innerHTML = menuMarkup;
console.dir(menuRef);
